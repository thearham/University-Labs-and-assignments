#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

//let talk about problem 
//take 2 arguments from commadn line 
//first argument denotes the number who's facorial got calculated
//the 2nd argument denotes the number of threads that will find facorial
//note that first argument must be greater or equal to 2nd else wrong input
//now each thread should display its calulated values
//then the parent thread means at the end of the main show the final results

//now there are the hints you task is to make algoritm that do the work properly
//think as much as you can



//created global variables to use over the porgram not only in main function
int size=0;

int calculateSize(int N,int M)
{
    //this functin call caluate the partition size
    //like that if 10 by 4 it calculate 3 
    //then the partition looks like
    //10x8x9 then 7x6x5 then 4x3x2 then 1 
    //so 10 calulated by 4 threads
    if(N%M==0) return N/M;
    else return ((N/M)+1);
}

int fact(int num,int range)
{
    //this factorial funciton calulate the factorialnumber to a reange
    //like i want o calulate factorail of 10 till 8
    //so this may work like 10x9x8 the retrun the result
    int result=1;
    while(num>range&&num>0)
    {
        result=result*num;
        num--;
    }
    return result;
}

void *findFactorial(void *x) {
    int *f = (int*)malloc(sizeof(int));
    *f = *((int*)x);
    //call the factorial functionto cagulate the results
    *f=fact(*f,*f-size);
    //printing area don't bother about it make it as you want
    if(*((int*)x)-size<0)
    {
        printf("Multiplication of numbers range from %d to ",*((int*)x));
        printf("1 is : %d\n",*f);
    }
    else
    {
        printf("Multiplication of numbers range from %d to ",*((int*)x));
        printf("%d is : %d\n",(*((int*)x)-size)+1,*f);
    }
    //free the allocated dynamic memory
    free(f);
    //retrun the data to main to make final result
    return (void*)f;
}


int main(int count,char** argv)
{
    //created 2 variables N and M to store the values coming from command line
    int N=atoi(argv[1]);
    int M=atoi(argv[2]);
    int temp;
    if(M<=N)
    {
        size = calculateSize(N,M);
        pthread_t *arrThread = (pthread_t*) malloc (sizeof(pthread_t)*M);
        for(int i=0;i<M;i++)
        {
            temp=N-(i*size);
            pthread_create(&arrThread[i],NULL,&findFactorial,(void*)&temp);
            sleep(2);
        }
    }
    else
    {
        printf("Wrong input.");
        
    }
    
    
    return 0;
}
