template <class T>
struct Node
{
	T data;
	Node*next;
	Node*prev;
};