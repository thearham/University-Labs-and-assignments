#include "Node.h"
#include <iostream>
using namespace std;
template <class T>
class LinkedList
{
protected:
	Node<T> *head;
	Node<T>	*tail;
public:
	LinkedList();
	virtual void insertAtTail(T) = 0;
	virtual void insertAtHead(T) = 0;
	virtual void displayFromTail() = 0;
	virtual void displayFromHead() = 0;
	virtual bool deletevalue(T) = 0;
};

template <class T>
LinkedList<T>::LinkedList()
{
	head = nullptr;
	tail = nullptr;
}