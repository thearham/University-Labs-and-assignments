#include "LinkedList.h"

template <class T>
class myLL:public LinkedList<T>
{
public:
	void insertAtTail(T);
	void insertAtHead(T);
	void displayFromTail();
	void displayFromHead();
	bool deletevalue(T);
};

template <class T>
bool myLL<T>::deletevalue(T value)
{
	if (head == nullptr && tail == nullptr)
		return false;

	else if (head == tail) //single node case
	{
		if (value == head->data)
		{
			delete head;
			head = nullptr;
			tail = nullptr;
			return true;
		}

		return false;
	}

	else if (value == head->data)
	{
		head = head->next;
		delete head->prev;
		head->prev = nullptr;
		return true;
	}

	else if (value == tail->data)
	{
		tail = tail->prev;
		delete tail->next;
		tail->next = nullptr;
		return true;
	}

	else
	{
		Node<T>*d = tail;
		
		while (1)
		{
			if (d->data == value)
			{
				d->prev->next = d->next;
				d->next->prev = d->prev;
				delete d;
				d = nullptr;
				return true;
			}

			d = d->prev;

			if (d == nullptr)
				return false;
		}
	}
}

template <class T>
void myLL<T>::displayFromTail()
{
	if (head == nullptr && tail == nullptr)
		cout << "LL is empty" << endl;

	else
	{
		Node<T> *temp = tail;
		while (1)
		{
			cout << temp->data << endl;
			temp = temp->prev;

			if (temp == nullptr)
				break;
		}

	}
}

template <class T>
void myLL<T>::displayFromHead()
{
	if (head == nullptr && tail == nullptr)
		cout << "LL is empty" << endl;

	else
	{
		Node<T> *temp = head;
		while (1)
		{
			cout << temp->data << endl;
			temp = temp->next;

			if (temp == nullptr)
				break;
		}

	}
}
template <class T>
void myLL<T>::insertAtHead(T value)
{
	if (head == nullptr && tail == nullptr)
	{
		Node<T> *nn = new Node<T>;
		nn->data = value;
		nn->next = nullptr;
		nn->prev = nullptr;

		head = nn;
		tail = nn;
	}

	else
	{
		Node<T> *nn = new Node<T>;
		nn->data = value;
		nn->next = nullptr;
		nn->prev = nullptr;

		nn->next = head;
		head->prev = nn;
		head = nn;
	}
}

template <class T>
void myLL<T>::insertAtTail(T value)
{
	if (head == nullptr && tail == nullptr)
	{
		Node<T> *nn = new Node<T>;
		nn->data = value;
		nn->next = nullptr;
		nn->prev = nullptr;

		head = nn;
		tail = nn;
	}

	else
	{
		Node<T> *nn = new Node<T>;
		nn->data = value;
		nn->next = nullptr;
		nn->prev = nullptr;

		nn->prev = tail;
		tail->next = nn;
		tail = nn;
	}
}