#include "myLL.h"

int main()
{
	myLL<int> obj;
	obj.insertAtTail(15);
	obj.insertAtTail(-3);
	obj.insertAtHead(8);
	obj.insertAtTail(1289);
	obj.insertAtHead(489);
	

	cout << "Deleted value = " << obj.deletevalue(999) << endl;

	cout << "Display From Head = " << endl;
	obj.displayFromHead();

	cout << "Display From Tail = " << endl;
	obj.displayFromTail();

	return 0;
}